from django.db import models

# Create your models here.


class employee(models.Model):
    # EmpId = models.AutoField(primary_key=True)
    EmpName = models.CharField(max_length=200)
    EmpEmail = models.CharField(max_length=200)
    EmpDepartment = models.CharField(max_length=50,choices=(('IT','IT'),('HR','HR'),('Accounts','Accounts'),('Finance','Fianace')))
    EmpDescription = models.TextField()
    EmpFile = models.FileField(upload_to='media')

    def __str__(self):
        return self.EmpName+" depatment is: "+self.EmpDepartment

# class userdetails(models.Model):
