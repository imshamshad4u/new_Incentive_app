from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import employee
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from rest_framework import viewsets
# from .serializers import employeeSerializer
# Create your views here.


@csrf_exempt
def index(request):
    
    test = employee.objects.all()

    if request.method == 'POST':
        empname = request.POST['empname']
        empemail = request.POST['empemail']

        empdept = request.POST['empdepartment']
        desc = request.POST['empdesc']
        empfile = request.POST['fileupload']
        # empfile = request.FILES.get('fileupload')

        # print("Test=======", test)
        # for data in test:
        #     print("id========", data.id)

        email = employee.objects.filter(EmpEmail=empemail)

        if email.exists():
            messages.warning(request, "Email already exist!",
                             extra_tags="alert-warning")
            return redirect('/')

        newemp = employee(EmpName=empname, EmpEmail=empemail,
                          EmpDepartment=empdept, EmpDescription=desc, EmpFile=empfile)
        newemp.save()
    context = {
        "test": test,
    
    }

    return render(request, "main.html", context)


def getdetails(request,id):
    # response = request.get('').json()
    # response = employee.objects.values_list("id", "EmpName")
    # response=employee.objects.filter('EmpEmail'=)
    response = employee.objects.filter(id=id)

    return render(request, 'login.html', {'response': response})

# @csrf_exempt
# def register(request):
#     return render(request, 'register.html')

# def login (request):
#     return render(request,'login.html')
# class employeeViewSet(viewsets.ModelViewSet):
#     queryset = employee.objects.all()
#     serializer_class = employeeSerializer
