from django.urls import path, include
from .import views
# from .views import employeeViewSet
# from rest_framework import routers
# router=routers.DefaultRouter()
# router.register(r'employee',employeeViewSet)
urlpatterns = [


    # path('register/', views.register, name="register"),
    # path('login', views.login, name="login"),
    # path('forms',views.index,name="index"),
    path('', views.index, name="index"),
    path('getdetails/<int:id>', views.getdetails, name="getdetails")
    # path('',include(router.urls))

]
