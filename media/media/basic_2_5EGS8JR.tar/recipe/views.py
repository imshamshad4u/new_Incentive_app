from django.shortcuts import render, redirect
from .models import *
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required


def home(request):
    queryset = Recipe.objects.all()
    search_request = request.GET.get('search')
    if search_request:
        # print(request.GET.get('search'))
        queryset = queryset.filter(recipe_name__icontains=search_request)
    context = {'recipes': queryset}
    return render(request, 'recipe/home.html', context)


def login_page(request):
    if request.user.is_authenticated:
        return redirect('/')
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        if not User.objects.filter(username=username).exists():
            messages.error(request, "Invalid Username")
            return redirect("/login")

        user = authenticate(username=username, password=password)

        if user is None:
            messages.error(request, "Invalid Password")
            return redirect('/login')

        else:
            login(request, user)
            return redirect('/')

    return render(request, 'recipe/login.html')


def logout_page(request):
    logout(request)
    return redirect('/login')


def register_page(request):
    if request.method == "POST":
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = User.objects.filter(username=username)

        if user.exists():
            messages.warning(request, "Username already taken.",
                             extra_tags="alert-danger")
            return redirect('/register')

        user = User.objects.create(
            first_name=first_name,
            last_name=last_name,
            username=username
        )

        user.set_password(password)
        user.save()

        messages.success(request, "Account Created Successfully.",extra_tags="alert-success")

        return redirect('/login')

    return render(request, 'recipe/register.html')


# @csrf_exempt
@login_required(login_url="/login")
def add_recipe(request):
    if request.method == "POST":
        data = request.POST

        user_id = request.user.id
        recipe_name = data.get('recipe_name')
        recipe_description = data.get('recipe_description')
        recipe_image = request.FILES.get('recipe_image')

        Recipe.objects.create(
            user_id=user_id, recipe_name=recipe_name, recipe_description=recipe_description, recipe_image=recipe_image)

        return redirect('/')

    return render(request, 'recipe/add-recipe.html')


@login_required(login_url="/login")
def delete_recipe(request, id):
    logged_user_id = request.user.id
    recipe_to_delete = Recipe.objects.get(id=id)
    if recipe_to_delete.user_id == logged_user_id:
        recipe_to_delete.delete()
        return redirect(f'/users/{logged_user_id}')
    return redirect(f'/users/{logged_user_id}')


@login_required(login_url="/login")
def update_recipe(request, id):
    logged_user_id = request.user.id
    queryset = Recipe.objects.get(id=id)

    if queryset.user_id == logged_user_id:
        if request.method == "POST":
            data = request.POST
            recipe_name = data.get('recipe_name')
            recipe_description = data.get('recipe_description')
            recipe_image = request.FILES.get('recipe_image')

            queryset.recipe_name = recipe_name
            queryset.recipe_description = recipe_description

            if recipe_image:
                queryset.recipe_image = recipe_image

            queryset.save()
            return redirect('/')

        context = {'recipe': queryset}
        # print(context)
        return render(request, 'recipe/update-recipe.html', context)
    return redirect(f'/users/{logged_user_id}')


def logged_in_user_page(request, id):
    logged_user_id = request.user.id
    # print(request.user.username)

    if id == logged_user_id:
        queryset = Recipe.objects.filter(user_id=id)
        profile_user = queryset[0].user.username

        context = {'users_data': queryset,
                   'logged_user_id': logged_user_id, 'profile_user': profile_user}
        return render(request, 'recipe/user-page.html', context)
    else:
        queryset = Recipe.objects.filter(user_id=id)
        if queryset.count() == 0:
            return redirect(f'/users/{int(logged_user_id)}')
        profile_user = queryset[0].user.username
        context = {'users_data': queryset, 'profile_user': profile_user}
        return render(request, 'recipe/user-page.html', context)



    return redirect('/')


@login_required(login_url='/login')
def recipe_page(request, id):
    queryset = Recipe.objects.get(id=id)
    print(queryset.user.username)
    context = {'recipe': queryset}
    return render(request, 'recipe/recipe-page.html', context)


